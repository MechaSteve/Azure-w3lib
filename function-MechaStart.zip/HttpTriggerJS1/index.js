const createHandler = require("azure-function-express").createHandler;
const express = require("express");

const app = express();

// View engine setup
app.set('views', 'D:\\home\\site\\wwwroot\\HttpTriggerJS1\\views');
app.set('view engine', 'pug');

app.get('/lib', (req, res) => {
  res.render('index');
});

// Binds the express app to an Azure Function handler
module.exports = createHandler(app);